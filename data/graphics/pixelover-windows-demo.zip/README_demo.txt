Thank you for trying PixelOver in pre-release. This version does not allow you to export your work.
Anyway, you can save it as a PixelOver project. Thus after getting the full version, you will be able to retrieve it.

Nevertheless, if you get the full application now, you will get all the new updates for no more. Thank you for helping the project: 
https://deakcor.itch.io/pixelover

The application will automatically tell you when a new update is available, but if you don't want to miss news, you can check: 
https://pixelover.io/roadmap/
or
#PixelOver on twitter

You can find some palettes in palette/ folder and dithering patterns in dithering/ folder.
You can also find shader presets which give default values to pixelation. In the application, they are registered as shader/favorite/.

If you face an issue or want to suggest new features or even ask questions, feel free to create a post here: 
https://deakcor.itch.io/pixelover/community

For Mac user:
Use right click>open when you launch the app for the first time, otherwise it won't open.